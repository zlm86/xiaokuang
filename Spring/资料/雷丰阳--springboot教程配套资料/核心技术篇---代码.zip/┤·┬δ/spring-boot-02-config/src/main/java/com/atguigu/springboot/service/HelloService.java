package com.atguigu.springboot.service;

public class HelloService {
}
